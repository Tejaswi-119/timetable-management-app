package com.example.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;




    public class Week_Activity<position> extends AppCompatActivity {

        ListView listView;
        String[] mTitle = {"Monday", "Tuesday","Wednesday","Thursday","Friday","Saturday"};

        int[] images = {R.drawable.m, R.drawable.t,R.drawable.w,R.drawable.ttjpg,R.drawable.f,R.drawable.s};
        // so our images and other things are set in array

        // now paste some images in drawable

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_week_);

            listView = findViewById(R.id.lvWeek);
            // now create an adapter class

            MyAdapter adapter = new MyAdapter(this, mTitle, images);
            listView.setAdapter(adapter);
            // there is my mistake...
            // now again check this..

            // now set item click on list view
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        if (position == 0) {
                            Intent intent = new Intent(Week_Activity.this, Monday.class);
                            startActivity(intent);

                        }



                    if (position == 1) {

                            Intent intent = new Intent(Week_Activity.this, tuesday.class);
                            startActivity(intent);


                    }
                    if (position == 2) {

                        Intent intent = new Intent(Week_Activity.this, wednesday.class);
                        startActivity(intent);


                    }
                    if (position == 3) {

                        Intent intent = new Intent(Week_Activity.this, thursady.class);
                        startActivity(intent);


                    }
                    if (position == 4) {

                        Intent intent = new Intent(Week_Activity.this, friday.class);
                        startActivity(intent);


                    }
                    if (position == 5) {

                        Intent intent = new Intent(Week_Activity.this, saturday.class);
                        startActivity(intent);


                    }

                }
            });
            // so item click is done now check list view
        }

        class MyAdapter extends ArrayAdapter<String> {

            Context context;
            String rTitle[];

            int rImgs[];

            MyAdapter(Context c, String[] title, int[] imgs) {
                super(c, R.layout.week, R.id.textView1, title);
                this.context = c;
                this.rTitle = title;

                this.rImgs = imgs;

            }

            @Override
            public View getView(int position,  View convertView,  ViewGroup parent) {
                LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View week = layoutInflater.inflate(R.layout.week, parent, false);
                ImageView images = week.findViewById(R.id.image);
                TextView myTitle = week.findViewById(R.id.textView1);


                // now set our resources on views
                images.setImageResource(rImgs[position]);
                myTitle.setText(rTitle[position]);





                return week;
            }
        }
    }


